#ifndef _READPPM_H_
#define _READPPM_H_

/* Functions implemented in readppm.cpp */

GLubyte* readPPMfile(char *filename, int *wp, int *hp);

#endif	/* _READPPM_H_ */
